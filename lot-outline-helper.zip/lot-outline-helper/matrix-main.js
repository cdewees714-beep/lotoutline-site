// Runs in the Matrix page itself (not the extension's sandbox) so it can hand files to Matrix's own uploader
// (Plupload, exposed as window.g_SWF_m_ucImageLoader on the Manage Photos page). Talks to matrix.js through window messages.
(() => {
  if (window.__loHelperMain) return; window.__loHelperMain = true;
  const say = m => window.postMessage({ source: 'lo-main', ...m }, location.origin);
  const findUploader = () => { if (window.g_SWF_m_ucImageLoader && window.g_SWF_m_ucImageLoader.addFile) return window.g_SWF_m_ucImageLoader;
    for (const k of Object.keys(window)) { try { const v = window[k]; if (v && typeof v.addFile === 'function' && typeof v.start === 'function' && Array.isArray(v.files)) return v; } catch (e) {} } return null; };
  const toFile = (dataUrl, name) => { const [head, b64] = dataUrl.split(','); const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
    const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new File([u], name, { type: mime, lastModified: Date.now() }); };
  let bound = false, up = null;
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.source !== 'lo-ext') return;
    const d = e.data;
    if (d.type === 'probe') { const u = findUploader(); return say({ type: 'probe', ok: !!u, state: u ? u.state : null }); }
    if (d.type === 'stop') { if (up) { try { up.stop(); } catch (err) {} } return say({ type: 'stopped' }); }
    if (d.type !== 'upload') return;
    up = findUploader(); if (!up) return say({ type: 'error', text: "Couldn't find Matrix's photo uploader on this page." });
    if (!bound) { bound = true;
      up.bind('UploadProgress', (u, f) => say({ type: 'progress', done: u.total.uploaded, total: u.files.length, percent: u.total.percent }));
      up.bind('FileUploaded', (u, f) => say({ type: 'fileDone', name: f.name, done: u.total.uploaded, total: u.files.length }));
      up.bind('UploadComplete', (u, files) => say({ type: 'complete', count: files.length, failed: u.total.failed }));
      up.bind('Error', (u, err) => say({ type: 'error', text: (err && err.message ? err.message : 'Upload error') + (err && err.file ? ` (${err.file.name})` : '') })); }
    // One at a time, in order: Matrix adds photos to the end of the gallery in the order they finish, so order in = order on the listing.
    try { up.setOption && up.setOption('max_file_count', 0); } catch (err) {}
    d.files.forEach(f => up.addFile(toFile(f.dataUrl, f.name), f.name));
    setTimeout(() => { if (up.state !== 2 /* plupload.STARTED */) up.start(); say({ type: 'started', total: d.files.length }); }, 300);
  });
  say({ type: 'loaded' });
})();
