// Lot Outline Helper: background worker. Holds one upload job at a time (photos + captions handed over by lotoutline.com)
// in the extension's own IndexedDB, opens the agent's Matrix tab, and relays progress back to the Lot Outline tab.
// No MLS login is ever asked for, read or stored: the upload runs inside the agent's own signed-in Matrix session.
const DB = 'lo-helper', STORE = 'kv';
const db = () => new Promise((res, rej) => { const r = indexedDB.open(DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(STORE); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const tx = async (mode, fn) => { const d = await db(); return new Promise((res, rej) => { const t = d.transaction(STORE, mode); const s = t.objectStore(STORE); const out = fn(s); t.oncomplete = () => res(out && out.result !== undefined ? out.result : out); t.onerror = () => rej(t.error); }); };
const get = k => tx('readonly', s => s.get(k));
const put = (k, v) => tx('readwrite', s => s.put(v, k));
const clearAll = () => tx('readwrite', s => s.clear());

async function relay(meta, msg) {   // tell the Lot Outline tab what's happening, if it's still open
  if (meta && meta.siteTab != null) { try { await chrome.tabs.sendMessage(meta.siteTab, { t: 'status', ...msg }); } catch (e) { /* tab closed: fine */ } }
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    switch (m.t) {
      case 'begin': {           // from lotoutline.com: a new job replaces any old one
        await clearAll();
        const meta = { id: m.job.id, address: m.job.address, mls: m.job.mls || '', count: m.job.count, received: 0, stage: 'receiving', siteTab: sender.tab ? sender.tab.id : null, created: Date.now() };
        await put('meta', meta); return { ok: true };
      }
      case 'photo': {
        await put('photo:' + m.i, { name: m.name, dataUrl: m.dataUrl, caption: m.caption || '' });
        const meta = await get('meta'); meta.received = Math.max(meta.received, m.i + 1); await put('meta', meta); return { ok: true };
      }
      case 'launch': {          // everything received: open Matrix in a new tab of the agent's own Chrome
        const meta = await get('meta'); if (!meta || meta.received < meta.count) return { ok: false, error: 'Not all photos arrived. Try Approve again.' };
        meta.stage = 'find-listing'; await put('meta', meta);
        const tab = await chrome.tabs.create({ url: 'https://matrix.harmls.com/Matrix/AddEdit', active: true }); meta.matrixTab = tab.id; await put('meta', meta);
        await relay(meta, { stage: meta.stage, text: 'Matrix is open in a new tab. Sign in there if it asks.' }); return { ok: true };
      }
      case 'get': return { meta: await get('meta') || null };
      case 'photos': { const meta = await get('meta'); const out = []; for (let i = 0; i < (meta ? meta.count : 0); i++) out.push(await get('photo:' + i)); return { photos: out }; }
      case 'stage': {
        const meta = await get('meta'); if (!meta) return { ok: false };
        Object.assign(meta, m.patch || {}, { stage: m.stage }); await put('meta', meta);
        await relay(meta, { stage: m.stage, text: m.text || '' });
        if (m.stage === 'done' || m.stage === 'cancelled') await clearAll();
        return { ok: true };
      }
      case 'ping': return { ok: true, version: chrome.runtime.getManifest().version };
      default: return { ok: false, error: 'unknown message' };
    }
  })().then(reply, e => reply({ ok: false, error: String(e && e.message || e) }));
  return true;   // async reply
});
