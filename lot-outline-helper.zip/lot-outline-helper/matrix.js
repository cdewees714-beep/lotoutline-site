// Lot Outline Helper inside HAR Matrix, in the agent's own signed-in tab. Walks one approved job through:
// Add/Edit → pick the listing → Manage Photos → upload (Matrix's own uploader) → fill each new photo's description →
// the agent reviews and clicks Certify and Save. It never deletes photos, never reorders them, never touches another field,
// and never clicks Certify and Save for the agent.
(() => {
  const send = m => new Promise(res => chrome.runtime.sendMessage(m, r => res(chrome.runtime.lastError ? null : r)));
  const stage = (s, text, patch) => send({ t: 'stage', stage: s, text, patch });
  const $ = (sel, root = document) => root.querySelector(sel), $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const CAP_SEL = 'textarea[id$="m_ucPhotoCell_m_tbxDescription"]';
  const MAX_CAP = 512;
  const pageText = () => document.body.innerText || document.body.textContent || '';

  // ---- floating panel ----
  let panel;
  function show(title, body, buttons = []) {
    if (!panel) { panel = document.createElement('div'); panel.className = 'lo-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Lot Outline Helper'); document.body.appendChild(panel); }
    panel.innerHTML = `<div class="lo-head"><span class="lo-logo"></span><span>Lot Outline Helper</span></div><b class="lo-title"></b><div class="lo-body"></div><div class="lo-btns"></div>`;
    panel.querySelector('.lo-title').textContent = title;
    const b = panel.querySelector('.lo-body'); if (body instanceof Node) b.appendChild(body); else b.textContent = body || '';
    const row = panel.querySelector('.lo-btns');
    buttons.forEach(([label, fn, primary]) => { const el = document.createElement('button'); el.type = 'button'; el.textContent = label; el.className = primary ? 'lo-btn lo-primary' : 'lo-btn'; el.onclick = fn; row.appendChild(el); });
  }
  const cancelBtn = ['Cancel upload', async () => { window.postMessage({ source: 'lo-ext', type: 'stop' }, location.origin); await stage('cancelled', 'You cancelled the upload in Matrix.'); show('Cancelled', 'Nothing more will be added. Photos already uploaded stay on the listing; remove them in Matrix if you want.'); }];

  // ---- messages from the page-side helper (matrix-main.js) ----
  const mainWaiters = [];
  window.addEventListener('message', e => { if (e.source !== window || !e.data || e.data.source !== 'lo-main') return; mainWaiters.slice().forEach(w => w(e.data)); });
  const onMain = fn => { mainWaiters.push(fn); return () => mainWaiters.splice(mainWaiters.indexOf(fn), 1); };

  // ---- listing match: MLS number first, then house number + street name ----
  const norm = t => (t || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  function matchListings(sel, meta) {
    const opts = [...sel.options].filter(o => o.value && o.value !== '-1');
    if (meta.mls) { const m = opts.filter(o => new RegExp(`\\b${meta.mls}\\b`).test(o.text)); if (m.length) return m; }
    const a = norm(meta.address), num = (a.match(/^(\d+)/) || [])[1], street = a.replace(/^\d+\s*/, '').split(' ')[0];
    if (!num || !street) return [];
    return opts.filter(o => { const t = norm(o.text); return new RegExp(`\\b${num} ${street}`).test(t); });
  }

  async function findListing(meta) {
    const sel = $('#m_lvInputUISections_ctrl0_ddlListings');
    if (!sel) return show('Waiting for Matrix', "Sign in to HAR Matrix in this tab. The helper picks up as soon as you're on Add/Edit.", [cancelBtn]);
    const hits = matchListings(sel, meta);
    const pick = async o => { const mlsNum = (o.text.match(/\b(\d{6,9})\b/) || [])[1] || ''; await stage('open-listing', `Opening ${o.text.replace(/^\S+\s+\S+\s+/, '')} in Matrix…`, { listingText: o.text, mlsNum });
      sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); show('Opening the listing…', o.text); };
    const list = document.createElement('div'); list.className = 'lo-list';
    if (hits.length === 1) {
      const p = document.createElement('p'); p.textContent = `Ready to add ${meta.count} photo${meta.count > 1 ? 's' : ''} to:`; const t = document.createElement('div'); t.className = 'lo-pick'; t.textContent = hits[0].text; list.append(p, t);
      return show('Found your listing', list, [['Start upload', () => pick(hits[0]), true], ['Pick a different listing', () => chooseFrom([...sel.options].filter(o => o.value && o.value !== '-1'), meta, pick)], cancelBtn]);
    }
    chooseFrom(hits.length ? hits : [...sel.options].filter(o => o.value && o.value !== '-1'), meta, pick, !hits.length);
  }
  function chooseFrom(opts, meta, pick, none) {
    const list = document.createElement('div'); list.className = 'lo-list';
    const p = document.createElement('p'); p.textContent = none ? `We couldn't match "${meta.address}" to one of your listings. Pick the right one:` : 'More than one listing matches. Pick the right one:'; list.appendChild(p);
    opts.slice(0, 40).forEach(o => { const b = document.createElement('button'); b.type = 'button'; b.className = 'lo-opt'; b.textContent = o.text; b.onclick = () => pick(o); list.appendChild(b); });
    show('Which listing?', list, [cancelBtn]);
  }

  // ---- Manage Photos ----
  const capBoxes = () => $$(CAP_SEL);
  const roomLeft = () => { const m = pageText().match(/\((\d+)\s*max\)/i); return m ? +m[1] : null; };
  const headerMls = () => (pageText().match(/Photos for MLS#\s*(\d+)/i) || [])[1] || '';

  async function upload(meta) {
    if (meta.mlsNum && headerMls() && headerMls() !== meta.mlsNum) { await stage('error', 'Matrix opened a different listing than the one picked.'); return show('Wrong listing', `This page is for MLS# ${headerMls()}, not ${meta.mlsNum}. Nothing was uploaded.`, [cancelBtn]); }
    const existing = capBoxes().length, left = roomLeft();
    if (left != null && meta.count > left) { await stage('error', `Matrix has room for ${left} more photos; the order has ${meta.count}.`); return show('Not enough room', `This listing has room for ${left} more photo${left === 1 ? '' : 's'} (50 max) and you're adding ${meta.count}. Remove some in Matrix first, then click Approve upload again on Lot Outline.`, [cancelBtn]); }
    const { photos } = await send({ t: 'photos' }); if (!photos || photos.length !== meta.count || photos.some(p => !p)) { await stage('error', 'The photos did not reach the helper.'); return show('Something went wrong', 'The photos did not reach the helper. Go back to Lot Outline and click Approve upload again.'); }
    await stage('uploading', `Uploading ${meta.count} photos to MLS# ${headerMls()}…`, { existing, expected: existing + meta.count, hasCaptions: photos.some(p => p.caption) });
    const bar = document.createElement('div'); bar.innerHTML = '<p class="lo-msg"></p><div class="lo-bar"><i></i></div>';
    const setBar = (done, pct) => { bar.querySelector('.lo-msg').textContent = existing ? `Adding after the ${existing} photo${existing > 1 ? 's' : ''} already on the listing. ${done} of ${meta.count} uploaded.` : `${done} of ${meta.count} uploaded.`; bar.querySelector('i').style.width = Math.max(3, pct) + '%'; };
    setBar(0, 0); show('Uploading your photos', bar, [cancelBtn]);
    const off = onMain(async d => {
      if (d.type === 'progress' || d.type === 'fileDone') setBar(d.done || 0, d.percent != null ? d.percent : Math.round(100 * (d.done || 0) / meta.count));
      if (d.type === 'error') { off(); await stage('error', d.text); show('Upload stopped', `Matrix said: ${d.text}. Photos that finished stay on the listing.`, [cancelBtn]); }
      if (d.type === 'complete') { off(); if (d.failed) { await stage('error', `${d.failed} photo(s) failed to upload.`); return show('Some photos failed', `${d.failed} of ${meta.count} didn't upload. The rest are on the listing.`, [cancelBtn]); }
        await stage('captions', 'Photos uploaded. Waiting for Matrix to show them…'); setBar(meta.count, 100); waitForPhotos(await meta2()); }
    });
    window.postMessage({ source: 'lo-ext', type: 'upload', files: photos.map(p => ({ name: p.name, dataUrl: p.dataUrl })) }, location.origin);
  }
  const meta2 = async () => (await send({ t: 'get' })).meta;

  // Matrix refreshes the photo grid after an upload (sometimes a full page reload). Wait until every new photo has its box.
  async function waitForPhotos(meta) {
    show('Almost there', 'Matrix is adding the photos to the gallery…', [cancelBtn]);
    for (let i = 0; i < 90; i++) { if (capBoxes().length >= meta.expected) return fillCaptions(meta); await sleep(1000); }
    show('Matrix is slow to refresh', `The upload finished, but the gallery shows ${capBoxes().length - meta.existing} of ${meta.count} new photos so far. Reload this page and the helper will finish the captions.`, [['Reload page', () => location.reload(), true], cancelBtn]);
  }

  async function fillCaptions(meta) {
    if (!meta.hasCaptions) return review(meta, false);
    const { photos } = await send({ t: 'photos' }); const boxes = capBoxes().slice(meta.existing, meta.existing + meta.count); const bad = [];
    boxes.forEach((ta, i) => { const text = ((photos[i] && photos[i].caption) || '').slice(0, Math.min(MAX_CAP, ta.maxLength > 0 ? ta.maxLength : MAX_CAP)); if (!text) return;
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set; setter.call(ta, text);
      ['input', 'change', 'blur'].forEach(ev => ta.dispatchEvent(new Event(ev, { bubbles: true })));
      if (ta.value !== text) bad.push(i + 1); });
    if (bad.length) { await stage('error', `Captions didn't stick on photo(s) ${bad.join(', ')}.`); return show('Check the captions', `The captions on photo${bad.length > 1 ? 's' : ''} ${bad.join(', ')} didn't stick. Paste them in by hand from your Lot Outline download (captions.txt), then click Certify and Save.`, [cancelBtn]); }
    review(meta, true);
  }

  async function review(meta, caps) {
    const save = $('#m_lbSave');
    await stage('review', `All ${meta.count} photos${caps ? ' and captions' : ''} are on the listing. Waiting for you to click Certify and Save in Matrix.`);
    if (save) { save.classList.add('lo-glow'); save.scrollIntoView({ behavior: 'smooth', block: 'center' }); save.addEventListener('click', () => stage('saving', 'Saving in Matrix…'), { once: true }); }
    const firstNew = capBoxes()[meta.existing]; if (firstNew) firstNew.closest('div[id$="m_ucPhotoCell_ctl00"]')?.classList.add('lo-mark');
    show('Ready for your review', `All ${meta.count} photo${meta.count > 1 ? 's are' : ' is'} on the listing${caps ? ' with captions' : ''}, after any photos that were already there. Look them over, then click Certify and Save (highlighted) to make it official.`, [['Show Certify and Save', () => save && save.scrollIntoView({ behavior: 'smooth', block: 'center' }), true]]);
  }

  // ---- route by page + stage ----
  (async () => {
    const r = await send({ t: 'get' }); const meta = r && r.meta; if (!meta) return;
    if (Date.now() - meta.created > 6 * 3600e3) { await stage('cancelled', 'Upload request expired.'); return; }   // stale job: drop it
    const path = location.pathname;
    if (meta.stage === 'saving') {
      const err = $$('.validationError, .errorMessage, [id*="ErrorMessage"]').map(e => (e.innerText || e.textContent || '').trim()).filter(Boolean)[0];
      if (err) return show('Matrix needs something', `Matrix said: ${err}`, [cancelBtn]);
      await stage('done', `Saved. ${meta.count} photos are on MLS# ${meta.mlsNum || ''}.`.replace(' # .', '.'));
      return show('Done', `Saved in Matrix. Your Lot Outline photos are live on the listing.`, [['Close', () => panel.remove(), true]]);
    }
    if (/\/Matrix\/AddEdit/i.test(path) && (meta.stage === 'find-listing' || meta.stage === 'open-listing')) return findListing(meta);
    if ($('#m_lbManagePhotos') && meta.stage === 'open-listing') { await stage('open-photos', 'Opening Manage Photos…'); show('Opening Manage Photos…', meta.listingText || ''); await sleep(400); return $('#m_lbManagePhotos').click(); }
    if ($('#m_lbSave') && capBoxes && /MediaManager/i.test(path)) {
      if (meta.stage === 'open-photos') { await sleep(800); return upload(meta); }
      if (meta.stage === 'uploading') return show('Upload interrupted', 'The page reloaded during the upload. Check which photos made it, then go back to Lot Outline and click Approve upload to try again.', [cancelBtn]);
      if (meta.stage === 'captions') return waitForPhotos(meta);
      if (meta.stage === 'review') return review(meta, meta.hasCaptions);
    }
    if (meta.stage === 'find-listing') return show('Lot Outline upload waiting', 'Go to Add/Edit in Matrix and the helper will find your listing.', [['Go to Add/Edit', () => { location.href = 'https://matrix.harmls.com/Matrix/AddEdit'; }, true], cancelBtn]);
  })();
})();
