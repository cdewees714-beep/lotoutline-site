// Lot Outline Helper on lotoutline.com: tells the page the helper is installed, takes the finished photos + captions
// the agent approved, hands them to the background worker, and passes progress back to the page.
(() => {
  const ORIGINS = ['https://lotoutline.com', 'https://www.lotoutline.com'];
  const version = chrome.runtime.getManifest().version;
  document.documentElement.dataset.loHelper = version;
  const toPage = msg => window.postMessage({ source: 'lo-helper', ...msg }, location.origin);
  const send = m => new Promise((res, rej) => chrome.runtime.sendMessage(m, r => chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(r)));
  toPage({ type: 'ready', version });

  window.addEventListener('message', async e => {
    if (e.source !== window || !ORIGINS.includes(e.origin)) return;
    const d = e.data; if (!d || d.source !== 'lo-site') return;
    if (d.type === 'hello') return toPage({ type: 'ready', version });
    if (d.type !== 'job') return;
    const job = d.job; if (!job || !Array.isArray(job.photos) || !job.photos.length) return toPage({ type: 'status', stage: 'error', text: 'No photos to upload.' });
    try {
      await send({ t: 'begin', job: { id: job.id, address: job.address, mls: job.mls, count: job.photos.length } });
      for (let i = 0; i < job.photos.length; i++) {
        const p = job.photos[i]; await send({ t: 'photo', i, name: p.name, dataUrl: p.dataUrl, caption: p.caption });
        toPage({ type: 'status', stage: 'receiving', text: `Handing photo ${i + 1} of ${job.photos.length} to the helper…` });
      }
      const r = await send({ t: 'launch' }); if (!r || !r.ok) throw new Error((r && r.error) || 'The helper could not open Matrix.');
    } catch (err) { toPage({ type: 'status', stage: 'error', text: err.message }); }
  });
  chrome.runtime.onMessage.addListener(m => { if (m && m.t === 'status') toPage({ type: 'status', stage: m.stage, text: m.text }); });
})();
