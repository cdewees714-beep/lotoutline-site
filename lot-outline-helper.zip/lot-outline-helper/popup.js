const st = document.getElementById('st'), cancel = document.getElementById('cancel');
const LABEL = { receiving: 'Getting your photos from Lot Outline…', 'find-listing': 'Waiting in Matrix: sign in and go to Add/Edit.', 'open-listing': 'Opening your listing in Matrix…',
  'open-photos': 'Opening Manage Photos…', uploading: 'Uploading photos to Matrix…', captions: 'Adding captions…', review: 'Ready: review the photos and click Certify and Save in Matrix.', saving: 'Saving in Matrix…', error: 'Stopped. Open the Matrix tab to see why.' };
chrome.runtime.sendMessage({ t: 'get' }, r => { const m = r && r.meta; if (!m) return;
  st.textContent = `${m.address}: ${LABEL[m.stage] || m.stage} (${m.count} photo${m.count > 1 ? 's' : ''})`; cancel.hidden = false; });
cancel.onclick = () => chrome.runtime.sendMessage({ t: 'stage', stage: 'cancelled', text: 'You cancelled the upload from the helper.' }, () => { st.textContent = 'Cancelled. Nothing more will be added.'; cancel.hidden = true; });
